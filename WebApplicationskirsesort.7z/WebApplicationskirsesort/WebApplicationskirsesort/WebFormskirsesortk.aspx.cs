﻿using LogicaSkirsesort;
using System;
using System.Collections.Generic;
using System.IO;
using LogicaSkirsesort;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplicationskirsesort
{
    public partial class WebFormskirsesortk : System.Web.UI.Page
    {
        static decimal[,] operando1;
        static decimal[,] operando2;
        int NumDere;
        int NumIzq;
        int NumDown;
        int NumDere1;
        int NumIzq1;
        int NumDown1;
        static string operador;
        static int[,] PositionDere;
        static int[,] Positionizq;
        static int[,] PositionDown;
        static int[,] PositionDere1;
        static int[,] Positionizq1;
        static int[,] PositionDown1;
        int mayor = 0;
        int filamay = 0;
        int columnamay = 0;
        int[,] result;
        string[] orden;
        string[] orden1;
        List<string> numCamino;
        List<string> numCamino2;
        List<string> numCamino3;
        List<string> numCamino4;
        List<string> numCamino5;
        List<string> numCamino6;
        List<string> numCamino7;
        List<string> numCamino8;
        List<string> numCamino9;
        List<string> numCamino10;
        List<string> numCamino11;
        List<string> numCamino12;
        List<string> numCamino13;
        List<string> numCamino14;
        List<string> numCamino15;
        int m = 0;
        int n = 0;
        int contador = 0;
        int cuentalongitud = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            Leer();
            Matrix matris = new Matrix(operando2);

            ImprimirCamino(operando2);

        }
        public void Leer()
        {
            //leo el archivo
            string path = Server.MapPath(@"~/map.txt");
            operador = File.ReadAllText(path);
            foreach (var item in operador.Split('\r'))
            {
                orden = operador.Split('\r');
                orden1 = operador.Split('\r');
                orden = orden[0].Trim().Split(' ');

                m = int.Parse(orden[0].ToString());
                n = int.Parse(orden[1].ToString());

                operando2 = new decimal[m, n];
                int i = 0, j = 0;

                for (int a = 1; a < orden1.Length; a++)
                {
                    foreach (var row in orden1[a].Trim().Split('\n'))
                    {
                        j = 0;
                        foreach (var col in row.Trim().Split(' '))
                        {
                            operando2[i, j] = int.Parse(col.Trim());
                            j++;
                        }
                        i++;
                    }
                }
            }
        }

        public void CountPath(int contador, int num)
        {
            if (contador >= 0)
            {
                if (cuentalongitud == 0)
                {
                    numCamino.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 1)
                {
                    numCamino2.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 2)
                {
                    numCamino3.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 3)
                {
                    numCamino4.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 4)
                {
                    numCamino5.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 5)
                {
                    numCamino6.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 6)
                {
                    numCamino7.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 7)
                {
                    numCamino8.Insert(contador, num.ToString());

                }
                if (cuentalongitud == 8)
                {
                    numCamino9.Insert(contador, num.ToString());

                }
            }
            contador = contador + 1;
        }

        public void SeguirCamino(decimal[,] m, int num, decimal[,] n, Matrix.Direction Direcition)
        {
            CountPath(contador, num);
            if (m.GetLength(1) == 0)
            {
                PositionDere1 = Move(Matrix.Direction.Right, num, m.GetLength(0), m.GetLength(1), n);
                if (n.GetLength(0) > PositionDere1.GetLength(0) && n.GetLength(1) > PositionDere1.GetLength(1))
                {
                    NumDere1 = Convert.ToInt32(operando2[PositionDere1.GetLength(0), PositionDere1.GetLength(1)]);

                }

                PositionDown1 = Move(Matrix.Direction.Down, num, m.GetLength(0), m.GetLength(1), m);
                if (n.GetLength(0) > PositionDown1.GetLength(0) && n.GetLength(1) > PositionDown1.GetLength(1))
                {
                    NumDown1 = Convert.ToInt32(operando2[PositionDown1.GetLength(0), PositionDown1.GetLength(1)]);

                }
                NumIzq1 = 0;

            }
            else if (0 <= m.GetLength(0) && 0 <= m.GetLength(1))
            {
                PositionDere1 = Move(Matrix.Direction.Right, num, m.GetLength(0), m.GetLength(1), m);
                if (n.GetLength(0) > PositionDere1.GetLength(0) && n.GetLength(1) > PositionDere1.GetLength(1))
                {
                    NumDere1 = Convert.ToInt32(operando2[PositionDere1.GetLength(0), PositionDere1.GetLength(1)]);

                }
                else NumDere1 = 0;

                Positionizq1 = Move(Matrix.Direction.Left, num, m.GetLength(0), m.GetLength(1), m);
                if (n.GetLength(0) > Positionizq1.GetLength(0) && n.GetLength(1) > Positionizq1.GetLength(1))
                {
                    NumIzq1 = Convert.ToInt32(operando2[Positionizq1.GetLength(0), Positionizq1.GetLength(1)]);

                }
                PositionDown1 = Move(Matrix.Direction.Down, num, m.GetLength(0), m.GetLength(1), m);
                if (n.GetLength(0) > PositionDown1.GetLength(0) && n.GetLength(1) > PositionDown1.GetLength(1))
                {
                    NumDown1 = Convert.ToInt32(operando2[PositionDown1.GetLength(0), PositionDown1.GetLength(1)]);

                }
            }


            if (Matrix.Direction.Right == Direcition)
            {
                if (NumIzq1 < num && num > NumDown1 && NumIzq1 > NumDown1)
                {
                    filamay = Positionizq1.GetLength(0);
                    columnamay = Positionizq1.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];

                    SeguirCamino(operando1, num, operando2, Matrix.Direction.Left);
                }
                if (NumDown1 < num && NumIzq1 > NumDown1)
                {
                    filamay = PositionDown1.GetLength(0);
                    columnamay = PositionDown1.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];
                    SeguirCamino(operando1, NumDown1, operando2, Matrix.Direction.Down);
                }
                if (NumDown1 < num && NumIzq1 < NumDown1)
                {
                    filamay = PositionDown1.GetLength(0);
                    columnamay = PositionDown1.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];
                    SeguirCamino(operando1, NumDown1, operando2, Matrix.Direction.Down);
                }

            }
            if (Matrix.Direction.Left == Direcition)
            {
                if (NumDere1 > 0)
                {
                    if (NumDere1 < num && NumDown1 > num)
                    {
                        filamay = PositionDere1.GetLength(0);
                        columnamay = PositionDere1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDere1, operando2, Matrix.Direction.Right);
                    }
                    else if (NumDown1 < num)
                    {

                        filamay = PositionDown1.GetLength(0);
                        columnamay = PositionDown1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDown1, operando2, Matrix.Direction.Down);
                    }
                }



            }
            if (Matrix.Direction.Down == Direcition)
            {

                if (NumIzq1 >= 0 && NumDown1 >= 0 && NumDere1 >= 0)
                {
                    if (NumDere1 < num && num > NumDown1 && NumDere1 >= NumDown1)
                    {
                        filamay = PositionDown1.GetLength(0);
                        columnamay = PositionDown1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDere1, operando2, Matrix.Direction.Right);
                    }
                    //Recorrer por izquierda o por abajo
                    if (NumIzq1 < num && num > NumDown1 && NumDown1 >= NumIzq1)
                    {
                        filamay = PositionDown1.GetLength(0);
                        columnamay = PositionDown1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDown1, operando2, Matrix.Direction.Down);
                    }
                    if (NumDere1 > num && num < NumDown1 && num < NumIzq1)
                    {
                        filamay = PositionDown1.GetLength(0);
                        columnamay = PositionDown1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDown1, operando2, Matrix.Direction.Down);
                    }

                    if (NumIzq1 > num && num < NumDown1 && NumDown1 <= NumIzq1 && NumDere1 < num)
                    {
                        filamay = PositionDere1.GetLength(0);
                        columnamay = PositionDere1.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDere1, operando2, Matrix.Direction.Right);
                    }

                }

            }
        }

        public void IniciarCamino(int mayor, int filamay, int columnamay, decimal[,] m)
        {

            if (filamay == 0 && columnamay == 0)
            {

                PositionDere = Move(Matrix.Direction.Right, mayor, filamay, columnamay, m);
                NumDere = Convert.ToInt32(operando2[PositionDere.GetLength(0), PositionDere.GetLength(1)]);
                PositionDown = Move(Matrix.Direction.Down, mayor, filamay, columnamay, m);
                NumDown = Convert.ToInt32(operando2[PositionDown.GetLength(0), PositionDown.GetLength(1)]);

                if (NumDere > NumDown || NumDown > NumIzq)
                {
                    //Recorre por derecha y por abajo
                    if (mayor > NumDere)
                    {

                        filamay = PositionDere.GetLength(0);
                        columnamay = PositionDere.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDere, operando2, Matrix.Direction.Left);
                    }
                    if (mayor > NumDown)
                    {

                        filamay = PositionDown.GetLength(0);
                        columnamay = PositionDown.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDown, operando2, Matrix.Direction.Down);
                    }
                }
                if (NumIzq > NumDown || NumDown > NumDere)
                {
                    //Recorre por izquierda y por abajo
                    if (mayor > NumIzq)
                    {

                        filamay = PositionDere.GetLength(0);
                        columnamay = PositionDere.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDere, operando2, Matrix.Direction.Left);
                    }
                    if (mayor > NumDown)
                    {

                        filamay = PositionDown.GetLength(0);
                        columnamay = PositionDown.GetLength(1);
                        operando1 = new decimal[filamay, columnamay];
                        SeguirCamino(operando1, NumDown, operando2, Matrix.Direction.Down);
                    }
                }

            }
            else if (filamay < m.GetLength(0) && columnamay < m.GetLength(1))
            {
                PositionDere = Move(Matrix.Direction.Right, mayor, filamay, columnamay, m);
                NumDere = Convert.ToInt32(operando2[PositionDere.GetLength(0), PositionDere.GetLength(1)]);
                PositionDown = Move(Matrix.Direction.Down, mayor, filamay, columnamay, m);
                NumDown = Convert.ToInt32(operando2[PositionDown.GetLength(0), PositionDown.GetLength(1)]);
                Positionizq = Move(Matrix.Direction.Left, mayor, filamay, columnamay, m);
                NumIzq = Convert.ToInt32(operando2[Positionizq.GetLength(0), Positionizq.GetLength(1)]);

                //Recorre por derecha, por abajo y por izquierda
                if (mayor > NumDere)
                {
                    filamay = PositionDere.GetLength(0);
                    columnamay = PositionDere.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];
                    SeguirCamino(operando1, NumDere, operando2, Matrix.Direction.Left);
                }
                if (mayor > NumDown)
                {
                    cuentalongitud = cuentalongitud + 1;
                    CountPath(contador, mayor);
                    filamay = PositionDown.GetLength(0);
                    columnamay = PositionDown.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];
                    SeguirCamino(operando1, NumDown, operando2, Matrix.Direction.Down);
                }
                if (mayor > NumIzq)
                {
                    cuentalongitud = cuentalongitud + 1;
                    CountPath(contador, mayor);
                    filamay = Positionizq.GetLength(0);
                    columnamay = Positionizq.GetLength(1);
                    operando1 = new decimal[filamay, columnamay];
                    SeguirCamino(operando1, NumIzq, operando2, Matrix.Direction.Right);
                }
            }
        }
        public void ImprimirCamino(decimal[,] m)
        {
            numCamino = new List<string>();
            numCamino2 = new List<string>();
            numCamino3 = new List<string>();
            numCamino4 = new List<string>();
            numCamino5 = new List<string>();
            numCamino6 = new List<string>();
            numCamino7 = new List<string>();
            numCamino8 = new List<string>();
            numCamino9 = new List<string>();
            numCamino10 = new List<string>();
            numCamino11 = new List<string>();
            numCamino12 = new List<string>();
            numCamino13 = new List<string>();
            numCamino14 = new List<string>();
            numCamino15 = new List<string>();

            for (int f = 0; f < m.GetLength(0); f++)
            {
                for (int c = 0; c < m.GetLength(1); c++)
                {
                    if (m[f, c] > mayor)
                    {
                        contador = 0;
                        mayor = Convert.ToInt32(m[f, c]);
                        filamay = f;
                        columnamay = c;
                        CountPath(contador, mayor);
                        IniciarCamino(mayor, filamay, columnamay, m);
                        cuentalongitud = cuentalongitud + 1;
                    }

                }

                if (numCamino.Count() > numCamino2.Count() && numCamino.Count() > numCamino3.Count() && numCamino.Count() > numCamino4.Count() && numCamino.Count() > numCamino5.Count())
                {
                    numCamino2 = new List<string>();
                    numCamino3 = new List<string>();
                    numCamino4 = new List<string>();
                    numCamino5 = new List<string>();
                    cuentalongitud = 1;

                }
                else if (numCamino.Count() < numCamino2.Count() && numCamino2.Count() > numCamino3.Count() && numCamino2.Count() > numCamino4.Count() && numCamino2.Count() > numCamino5.Count())
                {
                    numCamino = numCamino2;
                    numCamino2 = new List<string>();
                    numCamino3 = new List<string>();
                    numCamino4 = new List<string>();
                    numCamino5 = new List<string>();
                    cuentalongitud = 1;
                    //var sb = new System.Text.StringBuilder();
                    //for (int i = 0; i < numCamino2.Count(); i++)
                    //{

                    //    sb.AppendLine(numCamino[i].ToString());

                    //}
                    //lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                }
                else if (numCamino.Count() < numCamino3.Count() && numCamino2.Count() < numCamino3.Count() && numCamino3.Count() > numCamino4.Count() && numCamino3.Count() > numCamino5.Count())
                {
                    numCamino = numCamino3;
                    numCamino2 = new List<string>();
                    numCamino3 = new List<string>();
                    numCamino4 = new List<string>();
                    numCamino5 = new List<string>();
                    cuentalongitud = 1;
                }
                else if (numCamino.Count() < numCamino4.Count() && numCamino2.Count() < numCamino4.Count() && numCamino3.Count() < numCamino4.Count() && numCamino4.Count() > numCamino5.Count())
                {
                    numCamino = numCamino4;
                    numCamino2 = new List<string>();
                    numCamino3 = new List<string>();
                    numCamino4 = new List<string>();
                    numCamino5 = new List<string>();
                    cuentalongitud = 1;

                }
                else if (numCamino.Count() < numCamino5.Count() && numCamino2.Count() < numCamino5.Count() && numCamino5.Count() > numCamino4.Count() && numCamino3.Count() < numCamino5.Count())
                {
                    numCamino = numCamino5;
                    numCamino2 = new List<string>();
                    numCamino3 = new List<string>();
                    numCamino4 = new List<string>();
                    numCamino5 = new List<string>();
                    cuentalongitud = 1;

                }
                else if (numCamino.Count() == numCamino2.Count())
                {
                    for (int i = 0; i < numCamino.Count(); )
                    {
                        for (int j = 0; j < numCamino2.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino[i]) >= Convert.ToInt32(numCamino2[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino[i].ToString());
                                if (sb.Length == numCamino.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino2.Reverse();
                                for (int b = 0; b < numCamino2.Count(); b++)
                                {
                                    sb.AppendLine(numCamino2[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino2
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino2.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino.Count() == numCamino3.Count())
                {
                    for (int i = 0; i < numCamino.Count(); )
                    {
                        for (int j = 0; j < numCamino3.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino[i]) >= Convert.ToInt32(numCamino3[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino[i].ToString());
                                if (sb.Length == numCamino.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino3.Reverse();
                                for (int b = 0; b < numCamino3.Count(); b++)
                                {
                                    sb.AppendLine(numCamino3[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino3
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino3.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino.Count() == numCamino4.Count())
                {
                    for (int i = 0; i < numCamino.Count(); )
                    {
                        for (int j = 0; j < numCamino4.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino[i]) >= Convert.ToInt32(numCamino4[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino[i].ToString());
                                if (sb.Length == numCamino.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino4.Reverse();
                                for (int b = 0; b < numCamino4.Count(); b++)
                                {
                                    sb.AppendLine(numCamino4[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino4
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino4.Count();

                            }
                        }
                        break;
                    }


                }

                else if (numCamino.Count() == numCamino5.Count())
                {
                    for (int i = 0; i < numCamino.Count(); )
                    {
                        for (int j = 0; j < numCamino5.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino[i]) >= Convert.ToInt32(numCamino5[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino[i].ToString());
                                if (sb.Length == numCamino.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino5.Reverse();
                                for (int b = 0; b < numCamino5.Count(); b++)
                                {
                                    sb.AppendLine(numCamino5[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino5
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino5.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino2.Count() == numCamino3.Count())
                {
                    for (int i = 0; i < numCamino2.Count(); )
                    {
                        for (int j = 0; j < numCamino3.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino2[i]) >= Convert.ToInt32(numCamino3[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino2[i].ToString());
                                if (sb.Length == numCamino2.Count())
                                {
                                    numCamino2.Reverse();
                                    for (int b = 0; b < numCamino2.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino2[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino2
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino2.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino3.Reverse();
                                for (int b = 0; b < numCamino3.Count(); b++)
                                {
                                    sb.AppendLine(numCamino3[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino3
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino3.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino2.Count() == numCamino4.Count())
                {
                    for (int i = 0; i < numCamino2.Count(); )
                    {
                        for (int j = 0; j < numCamino4.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino2[i]) >= Convert.ToInt32(numCamino4[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino2[i].ToString());
                                if (sb.Length == numCamino2.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino2.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino2[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino2
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino2.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino4.Reverse();
                                for (int b = 0; b < numCamino4.Count(); b++)
                                {
                                    sb.AppendLine(numCamino4[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino4
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino4.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino2.Count() == numCamino5.Count())
                {
                    for (int i = 0; i < numCamino2.Count(); )
                    {
                        for (int j = 0; j < numCamino5.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino2[i]) >= Convert.ToInt32(numCamino5[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino2[i].ToString());
                                if (sb.Length == numCamino2.Count())
                                {
                                    numCamino.Reverse();
                                    for (int b = 0; b < numCamino2.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino2[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino2
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino2.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino5.Reverse();
                                for (int b = 0; b < numCamino5.Count(); b++)
                                {
                                    sb.AppendLine(numCamino5[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino5
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino5.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino3.Count() == numCamino4.Count())
                {
                    for (int i = 0; i < numCamino3.Count(); )
                    {
                        for (int j = 0; j < numCamino4.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino3[i]) >= Convert.ToInt32(numCamino4[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino3[i].ToString());
                                if (sb.Length == numCamino3.Count())
                                {
                                    numCamino3.Reverse();
                                    for (int b = 0; b < numCamino3.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino3[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino3
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino3.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino4.Reverse();
                                for (int b = 0; b < numCamino4.Count(); b++)
                                {
                                    sb.AppendLine(numCamino4[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino4
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino4.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino3.Count() == numCamino5.Count())
                {
                    for (int i = 0; i < numCamino3.Count(); )
                    {
                        for (int j = 0; j < numCamino5.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino3[i]) >= Convert.ToInt32(numCamino5[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino3[i].ToString());
                                if (sb.Length == numCamino3.Count())
                                {
                                    numCamino3.Reverse();
                                    for (int b = 0; b < numCamino3.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino3
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino3.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino5.Reverse();
                                for (int b = 0; b < numCamino5.Count(); b++)
                                {
                                    sb.AppendLine(numCamino5[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino5
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino5.Count();

                            }
                        }
                        break;
                    }

                }
                else if (numCamino4.Count() == numCamino5.Count())
                {
                    for (int i = 0; i < numCamino4.Count(); )
                    {
                        for (int j = 0; j < numCamino5.Count(); j++)
                        {
                            if (Convert.ToInt32(numCamino4[i]) >= Convert.ToInt32(numCamino5[j]))
                            {
                                i++;
                                var sb = new System.Text.StringBuilder();
                                sb.AppendLine(numCamino4[i].ToString());
                                if (sb.Length == numCamino4.Count())
                                {
                                    numCamino4.Reverse();
                                    for (int b = 0; b < numCamino4.Count(); b++)
                                    {
                                        sb.AppendLine(numCamino4[b].ToString());
                                    }

                                    lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                    var Descenso = (from a in numCamino4
                                                    select a).Max();
                                    lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                    lblLongitud.Text = "La longitud es de:" + numCamino4.Count();

                                }

                            }
                            else
                            {
                                var sb = new System.Text.StringBuilder();
                                numCamino5.Reverse();
                                for (int b = 0; b < numCamino5.Count(); b++)
                                {
                                    sb.AppendLine(numCamino5[b].ToString());
                                }

                                lblRutaCal.Text = "La mejor ruta calculada es:" + sb;
                                var Descenso = (from a in numCamino5
                                                select a).Max();
                                lblDescenso.Text = "El descenso es:" + Descenso.ToString();
                                lblLongitud.Text = "La longitud es de :" + numCamino5.Count();

                            }
                        }
                        break;
                    }

                }

            }
        }

        public int[,] Move(Matrix.Direction direction, int mayor, int filamay, int columnamay, decimal[,] m)
        {

            switch (direction)
            {
                case Matrix.Direction.Left:
                    result = new int[filamay, columnamay - 1];
                    break;
                case Matrix.Direction.Right:
                    result = new int[filamay, columnamay + 1];
                    break;
                case Matrix.Direction.Down:
                    result = new int[filamay + 1, columnamay];
                    break;


            }

            return result;

        }
    }
}
