﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaSkirsesort
{
    public class Matrix
    {
        decimal[,] matriz;

        public Matrix(decimal[,] m)
        {
            matriz = m;
        }

             public enum Direction
        {
            Down, Left, Right
        }
    }
}
